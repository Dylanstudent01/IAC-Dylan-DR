#!/bin/bash
# Student: Dylan van Raaij, Studentnummer:s1178037
printf "\n"
printf "#---------------------------#"
printf "# Het Self-service portaal! #"
printf "#---------------------------#"
printf "\n"
printf "\n"
#--------------------------------------------------------------------------------------------#
# Er word gevraagd naar de naam en het klantnummer. Dit wordt daarna ter bevestiging getoond #
#--------------------------------------------------------------------------------------------#
echo
read -p "Vul uw naam in? [bijv. Voornaam Achternaam]" _klantnaam
echo
read -p "wat is uw klantnummer? [1 - 254]" _klantnr
echo
echo "Welkom $_klantnaam met klantnummer $_klantnr."
echo
#----------------------------------------------#
# Er komt een keuzemenu voor het type omgeving #
#----------------------------------------------#
echo
 optie1="productie"
 optie2="test"

echo "Welke omgeving wilt u?"
options=("productie" "test")

select opt in "${options[@]}"
do
    case $opt in
        "productie")
            _omgeving=$optie1
            break
            ;;
        "test")
            _omgeving=$optie2
            break
            ;;
        *)
            echo "Ongeldige keuze, probeer opnieuw."
            ;;
    esac
done

echo "U wilt een $_omgeving omgeving"
echo

#--------------------------------------------------------------------------------------#
# Door de klantnaam en gekozen omgeving wordt de directory voor deze klant aangemaakt, #
# tevens wordt de inhoud van de productiemap gekopieerd naar de klant directory.       #
#--------------------------------------------------------------------------------------#
mkdir /home/student/IAC/klanten/$_klantnaam
mkdir /home/student/IAC/klanten/$_klantnaam/$_omgeving
cp -R /home/student/IAC/productie/bestanden/* /home/student/IAC/klanten/$_klantnaam/$_omgeving/
cd /home/student/IAC/klanten/$_klantnaam/$_omgeving
echo
echo
#----------------------------------------------------------# 
# Er wordt gevraagd hoeveel webservers de klant wil hebben #
#----------------------------------------------------------#
read -p "hoeveel webservers wilt u?" _countwebservers
echo
echo
echo "U wilt een $_omgeving omgeving voor klant $_klantnaam (klantnummer $_klantnr) met $_countwebservers webservers."
echo
read -p "Druk op enter om te bevestigen en uit te rollen:"
echo
#---------------------------------------------------------------------#
# Met de verzamelde gegevens wordt de Vagrantfile dynamisch aangevuld #
#---------------------------------------------------------------------#
sed -i "s/aantalweb/$_countwebservers/g" Vagrantfile
sed -i "s/klantnaam/$_klantnaam/g; s/omgeving/$_omgeving/g" Vagrantfile
sed -i "s/ip-range/10.0.$_klantnr/g" Vagrantfile
echo
echo "De omgeving wordt voor u uitgerold. Dit kan even duren, een moment geduld alstublieft."
echo
vagrant up
#---------------------------------------------------------------------#
# De Ansible inventory file wordt aangepast met de opgegeven waarden. #
# Ook wordt de ssh keyscan op de uitgerolde servers uitgevoerd        #
#---------------------------------------------------------------------#
 
sed -i "s/lb1/10.0.$_klantnr.21/g" inventory
sed -i "s/dbs1/10.0.$_klantnr.31/g" inventory

ssh-keyscan -H 10.0.$_klantnr.21 >> /home/student/.ssh/known_hosts
ssh-keyscan -H 10.0.$_klantnr.31 >> /home/student/.ssh/known_hosts 

for (( i=1; i<=$_countwebservers; i++ ))
do
    # Het IP-adres wordt gegenereerd zoals in de vagrantfile
    ip_address="10.0.$_klantnr.1$i"

    # De IP-adressen van de webserver(s) worden toegevoegd aan de inventory file
    echo $ip_address >> inventory

    # De IP-adressen van de webserver(s) worden toegevoegd aan het known_hosts bestand
    ssh-keyscan -H $ip_address >> /home/student/.ssh/known_hosts
done

echo "De omgeving is gedeployed. Nu volgt er een connection test"
echo
#--------------------------------#
# Connectivitiy test met Ansible #
#--------------------------------#
ansible all -m ping
echo
echo "Connection succes!, nog een moment geduld."
echo

ansible-playbook /home/student/IAC/klanten/$_klantnaam/$_omgeving/haproxy-deploy.yaml
ansible-playbook /home/student/IAC/klanten/$_klantnaam/$_omgeving/nginx-deploy.yaml
ansible-playbook /home/student/IAC/klanten/$_klantnaam/$_omgeving/mariadb-deploy.yaml
echo "#-------------------------------------------------#"
echo "# De omgeving is uitgerold en klaar voor gebruik! #"
echo "#-------------------------------------------------#"




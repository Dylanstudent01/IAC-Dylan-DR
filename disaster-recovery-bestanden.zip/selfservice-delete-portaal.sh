#!/bin/bash
# Student: Dylan van Raaij, Studentnummer:s1178037
printf "\n"
printf "#------------------------------#"
printf "# Self-service DELETE portaal! #"
printf "#------------------------------#"
printf "\n"
printf "\n"
# Als eerste wordt er gevraagd naar de klantnaam en de gewenste omgeving die de klant wil verwijderen.
echo
read -p "vul klantnaam in [voer de exacte naam in]:" _klantnaam
echo
echo
# Er komt een keuzemenu voor het type omgeving.
echo
 optie1="productie"
 optie2="test"

echo "Welke omgeving wilt u verwijderen?"
options=("productie" "test")

select opt in "${options[@]}"
do
    case $opt in
        "productie")
            _omgeving=$optie1
            break
            ;;
        "test")
            _omgeving=$optie2
            break
            ;;
        *)
            echo "Ongeldige keuze."
            ;;
    esac
done

echo
echo
echo
echo

# Aan de hand van de ingevulde gegevens wordt er naar deze omgeving genavigeerd. 

cd /home/student/IAC/klanten/$_klantnaam/$_omgeving

echo "De omgeving wordt doorlopen met het DESTROY menu:"
echo
pwd
echo 
read -p "Druk op enter om door te gaan:"
echo
echo "Kies telkens de optie y/n en druk vervolgens op enter voor elke machine:"

vagrant destroy

printf "#------------------------------------#"
printf "# Einde self-service DELETE portaal! #"
printf "#------------------------------------#"












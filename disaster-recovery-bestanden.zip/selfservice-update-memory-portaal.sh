#!/bin/bash
# Student: Dylan van Raaij, Studentnummer:s1178037
printf "\n"
printf "#------------------------------#"
printf "# Self-service UPDATE portaal! #"
printf "#------------------------------#"
printf "\n"
printf "\n"
#----------------------------------------------------------------------------------------#
# Er wordt gevraagd naar de klantnaam en de gewenste omgeving die de klant wil aanpassen #
#----------------------------------------------------------------------------------------#
echo
read -p "vul klantnaam in" _klantnaam
echo
#---------------------------------------------#
# Er komt een keuzemenu voor de type omgeving #
#---------------------------------------------#
 optie1="productie"
 optie2="test"

echo "Welkom $_klantnaam, welke omgeving moet er worden gewijzigd?"

options=("productie" "test")

select opt in "${options[@]}"
do
    case $opt in
        "productie")
            _omgeving=$optie1
            break
            ;;
        "test")
            _omgeving=$optie2
            break
            ;;
        *)
            echo "Ongeldige keuze, probeer opnieuw."
            ;;
    esac
done

echo "U wilt de $_omgeving omgeving van klant $_klantnaam wijzigen."
echo
read -p "Toets enter om te bevestigen:"
echo
echo
cd /home/student/IAC/klanten/$_klantnaam/$_omgeving

read -p "hoeveel webservers heeft uw $_omgeving omgeving?" _countwebservers
echo
#----------------------------------------------------------#
# er wordt weergegeven hoeveel geheugen de machines hebben #
#----------------------------------------------------------#
echo "De webservers hebben momenteel 1024 MB werkgeheugen"
echo
#----------------------------------------------------#
# keuzemenu voor het aanpassen van het  werkgeheugen #
#----------------------------------------------------#
 optie1="512"
 optie2="1024"
 optie3="2048"
 optie4="4096"

echo "Hoeveel MB werkgeheugen wilt u deze webservers instellen?"
options=("512" "1024" "2048" "4096")

select opt in "${options[@]}"
do
    case $opt in
        "512")
            _memory=$optie1
            break
            ;;
        "1024")
            _memory=$optie2
            break
            ;;
        "2048")
            _memory=$optie3
            break
            ;;
        "4096")
            _memory=$optie4
            break
            ;;
        *)
            echo "Ongeldige keuze, probeer opnieuw."
            ;;
    esac
done

echo "U wilt het geheugen van de webservers wijzigen naar $_memory MB."
echo
read -p "Toets enter om dit door te voeren:"
echo
echo "Het geheugen wordt gewijzigd, even geduld alstublieft."
#--------------------------------------------------------#
# Aanpassen van het geheugen van webservers met een loop #
#--------------------------------------------------------#

for (( i=1; i<=$_countwebservers; i++ ))
do
    VBoxManage controlvm $_klantnaam-$_omgeving-web0$i acpipowerbutton
    sleep 10
    VBoxManage modifyvm $_klantnaam-$_omgeving-web0$i --memory $_memory
    sleep 10
    VBoxManage startvm $_klantnaam-$_omgeving-web0$i --type headless

done

echo
echo "Het geheugen van de webservers is nu aangepast naar $_memory MB"
echo




CREATE TABLE IF NOT EXISTS werknemers (id int, name varchar(50));
INSERT INTO werknemers values (1,"s1178037 Dylan van Raaij");

